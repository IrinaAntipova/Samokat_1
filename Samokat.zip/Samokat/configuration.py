URL_SERVICE = "https://2750c6f1-e932-4c01-98b2-b899d80bfab8.serverhub.praktikum-services.ru/"
CREATE_ORDER_PATH = "api/v1/orders"
GET_ORDER_PATH = "api/v1/orders/track"
